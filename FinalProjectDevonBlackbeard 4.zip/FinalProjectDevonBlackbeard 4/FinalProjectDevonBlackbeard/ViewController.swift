//
//  ViewController.swift
//  quizApp
//
//  Created by Devon Blackbeard on 2019-06-15.
//  Copyright © 2019 Devon Blackbeard. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var finalname = ""
    override func viewDidAppear(_ animated: Bool)
    {
        newQuestion()
    }
    
    
    let questions = ["Which fictional city is the home of Batman?", "Spinach is high in which mineral?", "What is a Geiger Counter used to detect?", "Where is the capitol building in the USA?", "Babe Ruth is associated with which sport?", "Which country won the first FIFA World Cup in 1930?","What is the name of the man who launched eBay back in 1995", "Which Email service is owned by Microsoft?","Who is often called the father of the computer"]
    
    let answers = [["Gotham City", "Sunnydale", "Springfield"], ["Iron", "Zinc", "Potassium"], ["Radiation", "Mineral content", "Blood pressure"],["Washington DC", "Langely", "Tennessee"],["Baseball","Football","Hockey"],["England","Portugal","Uruguay"],["Larry Page","Pierre Omidyar","Elon Musk"],["Hotmail","Gmail","Mozilla"],["Andy Walker","Paul Fitzgerald","Charles Babbage"]]
    
    
    //Variables
    var currentQuestion = 0
    var rightAnswerPlacement:UInt32 = 0
    var points = 0
    
    //Label
    @IBOutlet weak var label: UILabel!
    
    
    
    
    //Button
    @IBAction func action(_ sender: AnyObject)
    {
        if (sender.tag == Int(rightAnswerPlacement))
        {
            print ("Right!")
            points += 1
        }
        else
        {
            print("Wrong!")
        }
        
        if (currentQuestion != questions.count)
        {
            newQuestion()
        }
            
        else
        {
            
            let alert = UIAlertController(title: "Ready to view results?", message: "No pressure....", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {action in
                self.performSegue(withIdentifier: "showScore", sender: self)
            }))
            
            alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: {action in
                self.view.layoutIfNeeded()}
                
            ))
            
            self.present(alert, animated: true)
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let score = segue.destination as! DestinationController
        
        score.finalscore = self.points
        let result:Double = Double(self.points)/Double(questions.count)
        print(result)
        
        let roundedResultview = round(result*1000)/1000
        score.roundedResult = roundedResultview
        
        let vc = segue.destination as! DestinationController
        vc.destinationname = finalname
    }
    
    
    
    //Function that displays new question
    func newQuestion()
    {
        label.text = questions[currentQuestion]
        
        rightAnswerPlacement = arc4random_uniform(3)+1
        
        //Create a button
        var button:UIButton = UIButton()
        
        var x = 1
        for i in 1...3
        {
            //Create a button
            button = view.viewWithTag(i) as! UIButton
            
            if ( i == Int( rightAnswerPlacement) )
            {
                button.setTitle(answers[currentQuestion][0], for: .normal)
            }
                
            else
            {
                button.setTitle(answers[currentQuestion][x], for: .normal)
                x = 2
            }
            
        }
        
        currentQuestion += 1
    }
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
}


