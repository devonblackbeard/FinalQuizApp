//
//  FavouritesViewController.swift
//  quizApp
//
//  Created by Devon Blackbeard on 2019-11-16.
//  Copyright © 2019 Devon Blackbeard. All rights reserved.
//

import UIKit

class FavouritesViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return categoryFavourites.count
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var pickerFavourites: UIPickerView!
    
    private let categoryFavourites = [
        "History", "Science", "Fiction", "Sports"
    ]

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return categoryFavourites[row]
    }
    
    @IBAction func selectButton(_ sender: Any)
    {
        let row = pickerFavourites.selectedRow(inComponent: 0)
        let selected = categoryFavourites[row]
        let title = "You selected \(selected)"
        
        let alert = UIAlertController(
            title: title,
            message: "We will show more of these questions",
            preferredStyle: .alert)
        
        let action = UIAlertAction(
            title: "OK",
            style: .default,
            handler: nil)
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    
    
}
