//
//  DestinationController.swift
//  quizApp
//
//  Created by Devon Blackbeard on 2019-09-12.
//  Copyright © 2019 Devon Blackbeard. All rights reserved.
//

import Foundation
import UIKit

class DestinationController: UIViewController
{
    
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var percentageLabel: UILabel!
    
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var contentSlider: UISlider!
    
    @IBOutlet weak var MessageTextView: UITextView!
    
    var finalscore = 0
    var percentage:Double = 0
    var roundedResult:Double = 0
    
    var destinationname = ""
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    
        
        scoreLabel.text = "\(finalscore)"
        percentageLabel.text = String(format: "%.1f", roundedResult*100) + "%"
        
        
        MessageTextView.text = "Thanks for playing \(destinationname)"
        
        print("IN destination controller")
    }
    
    
 
    
    
    
    
    
}


