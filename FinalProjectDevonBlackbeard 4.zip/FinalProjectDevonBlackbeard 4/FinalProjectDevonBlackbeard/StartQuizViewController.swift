//
//  StartQuizViewController.swift
//  FinalProjectDevonBlackbeard
//
//  Created by Devon Blackbeard on 2019-12-12.
//  Copyright © 2019 Devon Blackbeard. All rights reserved.
//

import UIKit
import CoreData

class StartQuizViewController: UIViewController {

    
    @IBOutlet weak var nameText: UITextField!
    
//    @IBOutlet weak var textView: UITextView!
    
    var userinput = String()
    
    override func viewDidLoad() {
        GetPreviousName()
        
        print("Previous name:" + "\(userinput)")
        nameText.text = userinput
       // nameText.delegate = self as? UITextFieldDelegate
       // let input = self.nameText.text
        
        // Do any additional setup after loading the view.
        
       // print("\(input)")
        super.viewDidLoad()
    }
    
    
    @IBAction func StartButton(_ sender: Any)
    {
        //print("\(nameText.text!)")
        
        // save the data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Username", in: context)
        let newEntity = NSManagedObject(entity: entity!, insertInto: context)
        
        newEntity.setValue(self.nameText.text!, forKey: "name")
        
        do
        {
            try context.save()
            print("Saved")
            print("in db i saved: \(self.nameText.text!)")
        }
        catch {
            print("Failed saving")
        }
    }
    
//    @IBAction func enterTapped(_ sender: Any) {
//        textView.text = "Name: \(nameText.text!)"
//
//    }
    
    func GetPreviousName()
    {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Username")
        request.returnsObjectsAsFaults = false
        
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject]
            {
                userinput = data.value(forKey: "name") as! String
            }
        }
        catch {
            print("Failed")
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let vc = segue.destination as! ViewController
        vc.finalname = self.nameText.text!
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
