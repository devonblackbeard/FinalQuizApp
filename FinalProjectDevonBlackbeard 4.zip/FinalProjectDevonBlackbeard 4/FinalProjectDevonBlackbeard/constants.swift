//
//  constants.swift
//  quizApp
//
//  Created by Devon Blackbeard on 2019-12-02.
//  Copyright © 2019 Devon Blackbeard. All rights reserved.
//

import Foundation

let difficultyKey = "difficulty"
let preferedLanguageKey = "language"


