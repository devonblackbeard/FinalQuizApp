//
//  FeedbackController.swift
//  quizApp
//
//  Created by Devon Blackbeard on 2019-10-20.
//  Copyright © 2019 Devon Blackbeard. All rights reserved.
//

import UIKit

class FeedbackController: UIViewController
{

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    
    @IBOutlet weak var feedbackLabel: UILabel!
    
    @IBAction func feedbackSwitch(_ sender: UISwitch)
    {
        if(sender.isOn)
        {
            feedbackLabel.text="Absolutely"
        }
        
        else
        {
            feedbackLabel.text="No"
        }
    }
    

}
