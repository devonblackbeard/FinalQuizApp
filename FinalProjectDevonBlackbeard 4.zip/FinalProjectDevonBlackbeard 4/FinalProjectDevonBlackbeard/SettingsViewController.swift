//
//  SettingsViewController.swift
//  quizApp
//
//  Created by Devon Blackbeard on 2019-12-02.
//  Copyright © 2019 Devon Blackbeard. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        refreshFields()
        // Do any additional setup after loading the view.
    }
    
   
    @IBOutlet weak var languageLabel: UILabel!
    @IBOutlet weak var difficultyLabel: UILabel!
    
    
    
    func refreshFields()
    {
        let defaults = UserDefaults.standard
        languageLabel.text = defaults.string(forKey: preferedLanguageKey)
        difficultyLabel.text = defaults.string(forKey: difficultyKey)
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        refreshFields()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        refreshFields()
    }


    @IBAction func onSettingsButtonTapped(_ sender: AnyObject) {
        let application = UIApplication.shared
        let url = URL(string: UIApplication.openSettingsURLString)! as URL
        if application.canOpenURL(url)
        {
            application.open(url, options:[UIApplication.OpenExternalURLOptionsKey(rawValue: ""):""] , completionHandler: nil)
        }
    }


}
